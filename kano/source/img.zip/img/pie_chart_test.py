import matplotlib.pyplot as plt
import numpy as np
plt.rcParams.update({'font.size': 22})
# data
explode = [0.05]
ratio = [0.6]

# append data and assign color
ratio.append(1-ratio[0])  # 50% blank
explode.append(0)  # 50% blank

colors = ['black', 'k']

# plot
fig, ax = plt.subplots(figsize=(12, 12))
wedges,texts = ax.pie(ratio, explode=explode, colors=colors, startangle=144)
fig.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0, wspace=0)
ax.axis('equal')
ax.margins(0,0)

wedges[-1].set_visible(False)

# autotexts[-1].set_visible(False)

plt.tight_layout()
plt.axis('off')
plt.savefig("no_line_2.png",facecolor='white',
    pad_inches=0,
    dpi=100, transparent=True,bbox_inches='tight')
